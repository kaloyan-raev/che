<?php
require_once dirname(__FILE__) . '/../../application/models/Blogs.php';

class MyBlog_Service
{
    /**
     * Get recent Blog entries
     *
     * @return struct
     */
    public function recentPosts()
    {
        $modelBlogs = new MyBlog_Model_Blogs();
        $recentEntries = '';
        try {
            $recentEntries = $modelBlogs->getRecentEntries();
        } catch (Zend_Db_Exception $e) {
            require_once 'MyBlog/Log.php';
            require_once 'MyBlog/Service/Exception.php';
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw new MyBlog_Service_Exception($e->getMessage());
        }

        return $recentEntries;
    }

    /**
     * Retrieve a blog entry
     *
     * @param  string $entryId
     * @return struct
     */
    public function getPost($entryId)
    {
        $modelBlogs = new MyBlog_Model_Blogs();
        $entry = '';
        try {
            $entry = $modelBlogs->getEntry($entryId);
        } catch (Zend_Db_Exception $e) {
            require_once 'MyBlog/Log.php';
            require_once 'MyBlog/Service/Exception.php';
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw new MyBlog_Service_Exception($e->getMessage());
        }

        return $entry;
    }

    /**
     * Post a new blog entry
     *
     * @return string
     */
    public function newPost()
    {
        return "Server returned new Post";
    }

    /**
     * Edit a blog entry
     *
     * @return string
     */
    public function editPost()
    {
        return "Server returned Edit Post";
    }
}
