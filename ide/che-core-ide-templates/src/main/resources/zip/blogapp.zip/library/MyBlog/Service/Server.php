<?php
class MyBlog_Service_Server
{
    /**
     * Singleton
     * @var MyBlog_Service_Server
     */
    protected static $_instance;

    /** @var Zend_XmlRpc_Server */
    protected $_xmlRpcServer;

    /**
     * Singleton instance
     * 
     * @return void
     */
    public static function getInstance()
    {
        if (null === self::$_instance) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Retrieve XML-RPC server
     * 
     * @return Zend_XmlRpc_Server
     */
    public static function getXmlRpcService()
    {
        return self::getInstance()->getXmlRpcServer();
    }

    /**
     * Constructor (singleton)
     *
     * Instantiate and configure XML-RPC server
     * 
     * @return void
     */
    protected function __construct() 
    {
    }

    /**
     * Retrieve XML-RPC server object
     * 
     * @return void
     */
    public function getXmlRpcServer()
    {
        if (null === $this->_xmlRpcServer) {
            require_once 'Zend/XmlRpc/Server.php';
            require_once 'MyBlog/Service.php';
            require_once 'MyBlog/Service/Exception.php';
            try {
                // Use exception class for Fault responses
                Zend_XmlRpc_Server_Fault::attachFaultException('MyBlog_Service_Exception');

                $this->_xmlRpcServer = new Zend_XmlRpc_Server();

                // Add namespace to the service
                // All public methods in the MyBlog_Service_Service class will be 
                // accessible as "myblog.METHODNAME"
                $this->_xmlRpcServer->setClass('MyBlog_Service', 'myblog');
            } catch (MyBlog_Service_Exception $e) {
                require_once 'MyBlog/Log.php';
                MyBlog_Log::getLogger()->err($e->getMessage());
            }
        }
        return $this->_xmlRpcServer;
    }
}
