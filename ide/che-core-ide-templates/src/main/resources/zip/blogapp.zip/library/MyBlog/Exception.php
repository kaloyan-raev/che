<?php
/**
 * MyBlog/Exception.php
 * 
 * @author Zend Technologies Inc.
 */

/**
 * MyBlog Exception Class
 *
 */
class MyBlog_Exception extends Exception 
{
}
