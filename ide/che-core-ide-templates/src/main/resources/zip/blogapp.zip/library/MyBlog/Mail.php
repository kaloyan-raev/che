<?php
/**
 * MyBlog/Mail.php
 *
 * @author Zend Technologies Inc.
 */

/**
 * MyBlog Mail Class
 */
class MyBlog_Mail
{
    /**
     * Retrieve mailer object
     * 
     * @return Zend_Mail
     */
    public static function getMailer()
    {
        // We could setup an alternate transport here -- sendmail, smtp, or a 
        // dummy logger.
        require_once 'Zend/Mail.php';
        return new Zend_Mail();
    }

    /**
     * Mail a comment
     * 
     * @param  string $commentTitle 
     * @return true
     */
    public static function mailNewComment($commentTitle) 
    {
        //SOME TEST DATA
        $subject   = 'Someone just commented on one of your blog posting!';
        $fromEmail = 'system@myblog';
        $from      = 'System Administrator';
        $toEmail   = 'administrator@myblog';
        $to        = 'Blog Administrator';
        $body      = '<p>You just received this comment on one of your blog entries</p><p>' . $commentTitle . '</p><p>Pl login to your account to approve or delete it.</p>';

        $mail      = self::getMailer();

        //Send mail to administrator
        $mail->setBodyText( $commentTitle)
             ->setFrom($fromEmail, $from)
             ->addTo($toEmail, $to)
             ->setSubject($subject);

        /** The Mail Send statement below has been intentionally commented out */
        //$mail->send();

        return true;
    }
}
