<?php
/**
 * MyBlog/Log.php
 *
 * @author Zend Technologies Inc.
 */

require_once 'Zend/Registry.php';
require_once 'Zend/Log.php';
require_once 'Zend/Log/Writer/Stream.php';

/**
 * MyBlog_Log
 *
 * Logs all messages to a log file defined in configuration.
 */
class MyBlog_Log
{
    /** @var Zend_Log */
    protected static $_log;

    /**
     * Retrieve logger instance
     * 
     * @return Zend_Log
     */
    public static function getLogger()
    {
        if (self::$_log === NULL)
        {
            $config     = Zend_Registry::get('config');
            $logFile    = $config->application->logs 
                        . date( 'Ymd') . '_' 
                        . $config->logger->filename;
            $writer     = new Zend_Log_Writer_Stream($logFile);
            self::$_log = new Zend_Log($writer);
            self::$_log->addWriter(new Zend_Log_Writer_Firebug());
        }

        return self::$_log;
    }
}
