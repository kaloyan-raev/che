<?php
/**
 * MyBlog/Search.php
 * 
 * @author Zend Technologies Inc.
 */

require_once 'Zend/Registry.php';
require_once 'Zend/Search/Lucene.php';
require_once 'Zend/Search/Lucene/Document.php';
require_once 'Zend/Search/Lucene/Field.php';

/**
 * MyBlog_Search Class
 * 
 * Provides methods to index and search for blog entries.
 */
class MyBlog_Search
{
    /**
     * Index a blog entry
     * 
     * @param  mixed $entry 
     * @return void
     */
    public static function indexEntry ($entry) 
    {
        try {
            $config = Zend_Registry::get('config');
            $searchIndexFile = $config->search->index->path . $config->search->index->filename;
            
            // Create a search index if not exists
            $indexerAction = 'append'; //Default action
            
            if (!file_exists($searchIndexFile)) {
                $indexerAction = 'create';
            }

            if ($indexerAction == 'create') {
                $index = Zend_Search_Lucene::create($searchIndexFile);
            } else {
                $index = Zend_Search_Lucene::open($searchIndexFile);
            }

            //Create a new Lucene document for adding to the Search index
            $doc = new Zend_Search_Lucene_Document();
            
            // Store entry id to identify it in search result. Stored in the index.
            $doc->addField(Zend_Search_Lucene_Field::Text('entry_id', $entry['entryId']));
            
            // Store document title. Stored in the index.
            $doc->addField(Zend_Search_Lucene_Field::Text('title', $entry['title']));
            
            // Index document content - but don't store in the index
            $doc->addField(Zend_Search_Lucene_Field::UnStored('content', $entry['content']));

            // Add document to the index.
            $index->addDocument($doc);
        } catch (Zend_Search_Lucene_Exception $e) {
            // Log this exception as an error
            require_once 'MyBlog/Log.php';
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
    }

    /**
     * 'Mon PHP_Error'
     * According to the documentation this function returned 'false' in case of non-indexed 
     * item related to the query.
     * The function is called when the user attempts a 'Search' in the application UI.
     * Exercise:
     * Register this user function for monitoring and verify it is properly monitored. 
     * 
     * Search the Lucene index based on a query.
     *  
     * @param  string $query 
     * @return array|bool Returns the indexed data if found or false otherwise
     */
    public static function search($query) 
    {
        $results = '';
        try {
            //Get search index file name from configuration file
            $config = Zend_Registry::get('config');
            $searchIndexFile = $config->search->index->path . $config->search->index->filename;
            $index = Zend_Search_Lucene::open($searchIndexFile);
            $hits = $index->find($query);
            $results  = array();
            $i = 0;
            if (count($hits) > 0) {
                foreach ($hits as $hit) {
                    // return Zend_Search_Lucene_Document object for this hit
                    $document = $hit->getDocument();
                    $tmp = array(
                        'entry_id'  => $document->entry_id,
                        'title'     => $document->title,
                   );
                    $results[$i] = $tmp;
                    $i++;
                }
            } else {
                $results = false;
            }
        } catch (Zend_Search_Lucene_Exception $e) {
            // Log this as an error
            require_once 'MyBlog/Log.php';
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        
        return $results;
    }
}
