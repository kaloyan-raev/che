<?php
class MyBlog_Service_Client
{
	protected $_client;

	protected static $_instance;

	public static function getInstance($options = null)
	{
		if (self::$_instance === null) {
			self::$_instance = new self($options);
		}
		return self::$_instance;
	}

	protected function __construct($options)
	{
        if ($options instanceof Zend_XmlRpc_Client) {
            $this->_setClient($options);
        } elseif (is_array($options) && array_key_exists('client', $options)) {
            $client = $options['client'];
            if (!$client instanceof Zend_XmlRpc_Client) {
                $message = 'Invalid client provided';

                require_once 'MyBlog/Log.php';
                MyBlog_Log::getLogger()->err($message);

                require_once 'MyBlog/Service/Exception.php';
                throw new MyBlog_Service_Exception($message);
            }

            $this->_setClient($client);
        } else {
            try {
                require_once 'Zend/Registry.php';
                require_once 'Zend/XmlRpc/Client.php';
                $this->_setClient(new Zend_XmlRpc_Client(
                    Zend_Registry::get('config')->url->myblog->service . '/service'
                ));
            } catch (Zend_XmlRpc_Exception $e) {
                require_once 'MyBlog/Log.php';
                MyBlog_Log::getLogger()->err($e->getMessage());
                throw $e;
            }
        }
	}

    protected function _setClient(Zend_XmlRpc_Client $client)
    {
        $this->_client = $client->getProxy();
        return $this;
    }

    /**
     * @return Zend_XmlRpc_Client_ServerProxy
     */
    protected function _getClient()
    {
        return $this->_client;
    }

	public function newPost()
	{
		try {
		  	return $this->_getClient()->myblog->newPost();
		} catch (Zend_XmlRpc_Exception $e) {
            require_once 'MyBlog/Log.php';
			MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
		}
	}

	public function getPost($entryId)
	{
		try {
		  	return $this->_getClient()->myblog->getPost($entryId);
		} catch (Zend_XmlRpc_Exception $e) {
            require_once 'MyBlog/Log.php';
			MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
		}
	}

	public function editPost()
	{
		try {
		  	return $this->_getClient()->myblog->editPost();
		} catch (Zend_XmlRpc_Exception $e) {
            require_once 'MyBlog/Log.php';
			MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
		}
	}

	public function recentPosts()
	{
		try {
		  	return $this->_getClient()->myblog->recentPosts();
		} catch (Zend_XmlRpc_Exception $e) {
            require_once 'MyBlog/Log.php';
			MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
		}
	}
}
