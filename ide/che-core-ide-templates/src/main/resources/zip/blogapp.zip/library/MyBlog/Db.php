<?php
/**
 * MyBlog/Db.php 
 * 
 * File contains the MyBlog_Db class.
 * Creates a connection on instantiation
 * 
 * @author Zend Technologies Inc.
 */

require_once 'Zend/Registry.php';
require_once 'Zend/Db.php';

/**
 * MyBlog_Ddb
 * Class acts as a factory to retrieve the database adapter.
 *
 */
class MyBlog_Db
{
    /**
     * @var Zend_Db_Adapter_Abstract
     */
    protected static $_adapter;
    
    /**
     * We make sure that only one instance of the database adapter is passed 
     * around
     *
     * @return Zend_Db_Adapter_Abstract
     */
    public static function getAdapter()
    {
        if (self::$_adapter === NULL) {
            try {
                $config = Zend_Registry::get('config')->database;

                // Get a conneciton to the SQLite database
                self::$_adapter = Zend_Db::factory($config);
            } catch (Zend_Db_Adapter_Exception $e) {
                // perhaps a failed login credential, or perhaps the RDBMS is not
                require_once 'MyBlog/Log.php';
                MyBlog_Log::getLogger()->err($e->getMessage());
                throw $e;
            } catch (Zend_Exception $e) {
                // perhaps factory() failed to load the specified Adapter class
                require_once 'MyBlog/Log.php';
                MyBlog_Log::getLogger()->err($e->getMessage());
                throw $e;
            }
        }
        
        return self::$_adapter;
    }    
}
