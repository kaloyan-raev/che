<?php
/**
 * MyBlog/Service/Exception.php
 *
 * MyBlog Service exception class
 *
 * @author Zend Technologies Inc.
 */

class MyBlog_Service_Exception extends Zend_Exception
{
}
