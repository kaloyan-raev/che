<?php
/**
 * MyBlog/Accesscontrol.php
 * 
 * @author Zend Technologies Inc.
 */

require_once 'Zend/Acl.php';
require_once 'Zend/Acl/Role.php';
require_once 'Zend/Acl/Resource.php';

/**
 * MyBlog_Acl Class
 * 
 * Defines Access Controls for the BLOG application.
 * The application basically defines two roles for users
 * Administrator and Guest
 * Defines resource admin area
 * A Guest is allowed to view blog entries and post comments.
 * While the Administrator can additionally create new Blog entries
 * approve comments via the admin area
 */
class MyBlog_Acl extends Zend_Acl
{
    public function __construct()
    {
        // Define Roles guest and admins
        $this->addRole(new Zend_Acl_Role('guest'))
             ->addRole(new Zend_Acl_Role('admin'));

        // Define the 'Guest' role as inheriting from the 'guest' role
        $this->addRole(new Zend_Acl_Role('Guest'), 'guest');

        // Define role for the user 'administrator' - the blog author in our 
        // application; inherits from both 'guest' and 'admin' roles
        $this->addRole(new Zend_Acl_Role('administrator'), array('guest', 'admin'));

        // Admin area for the application is defined here as a resource
        $this->add(new Zend_Acl_Resource('adminarea'));

        // Assign access control for the resource
        // Role 'guest' is denied access to the 'adminarea' resource
        $this->deny('guest', 'adminarea');

        //The user Administrator has access to all resources
        $this->allow('administrator', 'adminarea');
    }
}
