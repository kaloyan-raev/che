<?php
/**
 * MyBlog/Validator.php
 * 
 * @author Zend Technologies Inc.
 */

require_once 'Zend/Validate.php';
require_once 'Zend/Validate/StringLength.php';
require_once 'Zend/Validate/Alnum.php';
require_once 'Zend/Validate/EmailAddress.php';
require_once 'Zend/Filter.php';

/**
 * MyBlog_Validator Class
 * 
 * Provides static methods for validating and filtering input data
 */
class MyBlog_Validator 
{
}
