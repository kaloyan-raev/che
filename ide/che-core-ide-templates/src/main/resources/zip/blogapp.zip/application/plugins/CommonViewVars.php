<?php
class MyBlog_Plugin_CommonViewVars extends Zend_Controller_Plugin_Abstract
{
	public function dispatchLoopStartup(Zend_Controller_Request_Abstract $request)
	{
        $config  = Zend_Registry::get('config');
		$urlHome = $config->url->home;
		if ($urlHome == '/') {
			$urlHome = 'http://' . $request->getServer('HTTP_HOST');
		}

        $viewRenderer = Zend_Controller_Action_HelperBroker::getStaticHelper('viewRenderer');
        $viewRenderer->initView();
        $viewRenderer->view->assign(array(
            'urlHome' 				=> $urlHome,
            'applicationCopyright'	=> $config->application->copyright,
            'path'					=> $config->application->logs,
        ));
	}
}
