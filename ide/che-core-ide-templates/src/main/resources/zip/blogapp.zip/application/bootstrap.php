<?php
// Get application configuration and store in the registry

// Get application configuration object and store in the registry
$config = new Zend_Config_Ini(APPLICATION_PATH . '/config/Blog.ini', APPLICATION_ENV);
// Add config to the registry
Zend_Registry::set('config', $config);

//Set timezone
if (isset($config->timezone))
    date_default_timezone_set($config->timezone);
else
    date_default_timezone_set('America/Los_Angeles');

// If user not logged in, default username is explicitely set to 'Guest'
$auth = Zend_Auth::getInstance();
if (!$auth->hasIdentity()) {
    $identity = new stdClass;
    $identity->username = 'Guest';
    $auth->getStorage()->write($identity);
}

// Get the front controller instance and register the Error Handler
$front = Zend_Controller_Front::getInstance();

// Setup layouts
Zend_Layout::startMvc(array(
    'layoutPath' => APPLICATION_PATH . '/layouts/scripts',
));

// Setup view
// Set DocType, initial page title, and stylesheets link
$view = Zend_Layout::getMvcInstance()->getView();
$view->doctype('XHTML1_STRICT');
$view->headTitle()->setSeparator(' - ')->append($config->application->name);
$view->headLink()->appendStylesheet($config->url->styles);

// Register plugins
// CommonViewVars plugin registers common view variables with the view object
require_once APPLICATION_PATH . '/plugins/CommonViewVars.php';
$front->registerPlugin(new MyBlog_Plugin_CommonViewVars());

//Set path to controller directory
//we set it here for the default module
$front->setControllerDirectory(APPLICATION_PATH . '/controllers');

if ('development' == APPLICATION_ENV) {
    $front->throwExceptions(true);   
}
