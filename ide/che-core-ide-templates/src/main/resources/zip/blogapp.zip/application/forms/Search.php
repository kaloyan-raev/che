<?php
class MyBlog_Form_Search extends Zend_Form
{
    public function init()
    {
        $this->addElement('text', 'title', array(
            'size'       => 20,
            'maxlength'  => 120,
            'decorators' => array(
                'ViewHelper',
                array('HtmlTag', array('tag' => 'p')),
            ),
        ));

        $this->addElement('submit', 'Search', array(
            'label'      => 'Search',
            'ignore'     => true,
            'size'       => 10,
            'decorators' => array(
                'ViewHelper',
                array('HtmlTag', array('tag' => 'p')),
            ),
        ));

        $this->setDecorators(array(
            'FormElements',
            'Form',
            array('htmlTag', array('tag' => 'div', 'id' => 'wiki-search-box')),
        ));
    }
}
