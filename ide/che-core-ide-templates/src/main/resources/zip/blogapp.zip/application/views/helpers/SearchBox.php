<?php
require_once APPLICATION_PATH . '/forms/Search.php';

class Zend_View_Helper_SearchBox extends Zend_View_Helper_Abstract
{
    public function searchBox()
    {
        $urlHome = $this->view->urlHome;
        $form    = new MyBlog_Form_Search(array(
            'method' => 'get',
            'action' => "$urlHome/article/view/",
        ));

        return $form->__toString();
    }
}
