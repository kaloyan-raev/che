<?php
/**
 * models/Comments.php
 * File contains the MyBlog_Model_Comments class.
 * Class for Database manip operations.
 *
 * @author Zend Technologies Inc.
 */
require_once dirname(__FILE__) . '/Base.php';
/**
 * MyBlog_Model_Comments
 * Class contains methods for manipulating the BLOGS comment data stored
 * in SQLite database.
 *
 */
class MyBlog_Model_Comments extends MyBlog_Model_Base
{
    const SHOW_COMMENT = 1;
    const HIDE_COMMENT = 2;
    public function addComment (array $comment)
    {
        $lastCommentId = false;
        $title = $comment['title'];
        $email = $comment['email'];
        $content = $comment['comment'];
        $approvalStatus = (int) $comment['approvalStatus'];
        $entryId = (int) $comment['entry_id'];
        // Zend_Debug::dump($article, 'article Content: ', true);
        $data = array('title' => $title , 'comment' => $content , 'email' => $email , 'approval_status' => $approvalStatus , 'entry_id' => $entryId , 'modified' => time());
        $db = MyBlog_Db::getAdapter();
        try {
            // ZF Manual 9.1.4.1.
            // By default, the values in your data array are inserted using parameters.
            // This reduces risk of some types of security issues.
            // You don't need to apply escaping or quoting to values in the data array.
            $db->insert('blogcomments', $data);
            $id = $db->lastInsertId();
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        return $id;
    }
    public function getCommentCountByEntryId ($entryId)
    {
        $entryId = (int) $entryId;
        $db = MyBlog_Db::getAdapter();
        $select = $db->select();
        $select->from('blogcomments', array('comments_count' => new Zend_Db_Expr('COUNT(*)')))
               ->where('entry_id = ?', $entryId)
               ->where('approval_status = ?', 1);
        try {
            $result = $db->fetchOne($select);
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        return ($result) ? $result : 0;
    }
    /**
     * 'Datacache'
     * According to the documentation, this function will return
     * all the comments related to an article (based on its id).
     * Exercise:
     * Cache the result of the select query on disk for 5 secs.
     * Make sure the 'article id' and this 'comments' logic we are 
     * working on are properly reflected in the caching key.   
     * 
     * Returns all the comment related to an article
     *
     * @param int $entryId The article id
     * @return array The comments related to id
     */
    public function getComments ($entryId)
    {
        $entryId = (int) $entryId;
        $db = MyBlog_Db::getAdapter();
        $select = $db->select();
        $select->from('blogcomments')
               ->where('entry_id = ?', $entryId)
               ->where('approval_status = ?', 1)
               ->order('modified DESC');
        try {
            $stmt = $select->query();
            $results = $stmt->fetchAll(Zend_Db::FETCH_OBJ);
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        return $this->_fixPdoKeysRecursive($results);
    }
    public function getAllComments ()
    {
        $db = MyBlog_Db::getAdapter();
        $select = $db->select();
        $select->from('blogcomments')
               ->order('modified DESC');
        try {
            $stmt = $select->query();
            $results = $stmt->fetchAll(Zend_Db::FETCH_OBJ);
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        return $this->_fixPdoKeysRecursive($results);
    }
    public function updateCommentStatus ($commentId, $status)
    {
        $commentId = (int) $commentId;
        $data = array('approval_status' => (int) $status);
        $db = MyBlog_Db::getAdapter();
        try {
            $db->update('blogcomments', $data, 'comments_id = ' . $db->quote($commentId));
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
    }
}
