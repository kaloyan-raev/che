<?php
class Zend_View_Helper_Header extends Zend_View_Helper_Abstract
{
    public function header() 
    {
        $username        = Zend_Auth::getInstance()->getIdentity()->username;
        $applicationName = $this->view->applicationName;
        $urlHome         = $this->view->urlHome;
        $welcome         = 'Welcome <span class="bold">' . $username . '</span>';
        
        if ($username != 'Guest') {
            $welcome .= ' - <a href="' . $urlHome . '/admin">Manage</a> | <a href="' . $urlHome . '/user/logout">logout</a>';    
        } else {
            $welcome .= ' - <a href="' . $urlHome . '/user">login</a>';    
        }
        
        $headerHtml = <<<EOQ
<div id="header">
    
    <a href="$urlHome">Home</a> | $welcome
    <h1>$applicationName  
        <a href="http://framework.zend.com/" target="zfwindow">
            <img src="$urlHome/images/PoweredBy_ZF_4LightBG.png" border="0">
        </a>
    </h1>        
</div>
EOQ;

        return $headerHtml;
    }
}
