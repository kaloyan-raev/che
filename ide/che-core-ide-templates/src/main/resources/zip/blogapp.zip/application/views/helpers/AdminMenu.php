<?php
class Zend_View_Helper_AdminMenu extends Zend_View_Helper_Abstract
{
    public function adminMenu() 
    {
        $urlHome = $this->view->urlHome;
        
        $adminMenuHtml = <<<EOQ
            <ul>
                <li><a href="$urlHome/admin">Admin Home</a> </li>
                <li><a href="$urlHome/user/logout">Logout</a> </li>
            </ul>
            
            <h3>Blog entries</h3>
            <ul>
                <li><a href="$urlHome/admin/new-entry">Add New Entry</a></li>                
                <li><a href="$urlHome/admin/manage-entries">Manage Entries</a></li>
            </ul>
            <h3>Comments</h3>
            <ul>    
                <li><a href="$urlHome/admin/manage-comments">Manage comments</a></li>    
            </ul>    
            
EOQ;
        return $adminMenuHtml;
    }
}
