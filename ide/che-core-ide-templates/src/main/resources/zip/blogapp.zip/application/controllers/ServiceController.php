<?php
class ServiceController extends Zend_Controller_Action
{
    public function init()
    {
        $this->_helper->viewRenderer->setNoRender(true);
        $this->_helper->layout->disableLayout();
    }

    public function indexAction()
    {
        $server = MyBlog_Service_Server::getXmlRpcService();
        echo $server->handle();
    }
}
