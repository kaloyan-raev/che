<?php
class MyBlog_Form_Entry extends Zend_Form
{
    public function init()
    {
        $this->setName('admin-form');

        $this->addElement('text', 'title', array(
            'label'     => 'Title for your entry:',
            'size'      => 40,
            'maxlength' => 120,
            'required'  => true,
            'filters'   => array(
                'StringTrim',
            ),
            'validators' => array(
                array('StringLength', true, array(1, 120)),
            ),
        ));

        $this->addElement('textarea', 'content', array(
            'label'     => 'Blog Entry:',
            'required'  => true,
            'filters'   => array(
                'StringTrim',
            ),
            'validators' => array(
                array('StringLength', false, array(1, 2000)),
            ),
        ));

        $this->addElement('submit', 'Create', array(
            'label'  => 'Create',
            'ignore' => true,
        ));
    }
}
