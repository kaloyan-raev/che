<?php
/**
 * models/Blogs.php
 * File contains the MyBlog_Model_Blogs class.
 * Class for Database manip operations.
 *
 * @author Zend Technologies Inc.
 */

require_once dirname(__FILE__) . '/Base.php';

/**
 * MyBlog_Model_Blogs
 * Class contains methods for manipulating the blog data stored
 * in SQLite database.
 *
 */
class MyBlog_Model_Blogs extends MyBlog_Model_Base
{
    /**
     * function gets all Blog entries in the db
     *
     * @return mixed - result set containing all records in the listings table
     *
     * fetchall: returns an array of rows, each of which is an associative array.
     * The keys of the associative array are the columns or column aliases named in the select query.
     */
    public function getEntries()
    {
        $db = MyBlog_Db::getAdapter();
        $select = $db->select();
        $select->from(
                   array('a' => 'blogentries'), 
                   array(
                       'entry_id', 
                       'title', 
                       'content', 
                       'modified', 
                  )
               )
               ->group('a.entry_id')
               ->order('a.modified DESC');

        try {
            $stmt    = $select->query();
            $results = $stmt->fetchAll(Zend_Db::FETCH_OBJ);
        } catch (Zend_Db_Exception $e) {
            throw $e;
        }
        return $this->_fixPdoKeysRecursive($results);
    }

    /**
     * function gets a list of Article title in the BLog database
     *
     * @return mixed - array of rows containing title, listing_id and modified date
     */
    public function getEntryTitles()
    {
        $db     = MyBlog_Db::getAdapter();
        $select = $db->select();
        $select->from(
                   array('a' => 'blogentries'),
                   array(
                       'entry_id',
                       'title',
                       'modified',
                  )
               )
               ->group('a.entry_id')
               ->order('a.modified DESC');

        try {
            $stmt    = $select->query();
            $results = $stmt->fetchAll(Zend_Db::FETCH_OBJ);
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        return $this->_fixPdoKeysRecursive($results);
    }

    public function getEntry($entryId)
    {
        $entryId = (int) $entryId;
        $db      = MyBlog_Db::getAdapter();
        $select  = $db->select();
        $select->from(
                   array('a' => 'blogentries'),
                   array(
                       'entry_id',
                       'title',
                       'modified',
                       'content',
                   )
               )
               ->where('a.entry_id = ?', $entryId)
               ->group('a.entry_id');

        MyBlog_Log::getLogger()->info('SQL: ' . $select->__toString());

        $stmt  = $select->query();
        $entry = $stmt->fetch(Zend_Db::FETCH_OBJ);

        if (!$entry) {
            return $entry;
        }

        $entry = $this->_fixPdoKeys($entry);

        require_once dirname(__FILE__) . '/Comments.php';
        $commentsModel = new MyBlog_Model_Comments();
        $entry->comments_count = $commentsModel->getCommentCountByEntryId($entryId);
        return $entry;
    }

    public function createEntry($entry)
    {
        $title   = $entry['title'];
        $content = $entry['content'];
        $data    = array(
            'title'    => $title,
            'content'  => $content,
            'modified' => time(),
       );
        $db      = MyBlog_Db::getAdapter();

        try {
            $db->insert('blogentries', $data);
            $id = $db->lastInsertId();
        } catch (Zend_Db_Exception  $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        return $id;
    }

    public function getRecentEntries()
    {
        $db      = MyBlog_Db::getAdapter();
        $select  = $db->select();
        $select->from('blogentries', array('entry_id', 'title', 'modified'))
               ->order('modified DESC')
               ->limit(5, 0);

        try {
            $stmt    = $select->query();
            $results = $stmt->fetchAll(Zend_Db::FETCH_OBJ);
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }
        return $this->_fixPdoKeysRecursive($results);
    }
}
