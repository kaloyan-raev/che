<?php
/**
 * models/Users.php
 * File contains the MyBlog_Model_Users class.
 * Class for Database manip operations.
 *
 * @author Zend Technologies Inc.
 */

require_once dirname(__FILE__) . '/Base.php';

/**
 * MyBlog_Model_Users
 * Class contains methods for manipulating the BLOGS user data stored
 * in SQLite database.
 *
 */
class MyBlog_Model_Users extends MyBlog_Model_Base
{
    /**
     * Retrieve authentication adapter
     * 
     * @param  string $username 
     * @param  string $password 
     * @return Zend_Auth_Adapter_Interface
     */
    public static function getAuthAdapter($username, $password)
    {
        $authAdapter = new Zend_Auth_Adapter_DbTable(
            MyBlog_Db::getAdapter(), 
            'blogusers', 
            'username', 
            'password'
        );
        $authAdapter->setIdentity($username)
                    ->setCredential($password);

        return $authAdapter;
    }

    /**
     * Fetch user details
     * 
     * @param  string $username 
     * @return stdClass|null
     */
    public function getUserDetails($username)
    {
        $db     = MyBlog::getAdapter();
        $select = $db->select();
        $select->from('blogusers', array('user_id', 'real_name'))
               ->where('username = ?', $username);
        $db->setFetchMode(Zend_Db::FETCH_OBJ);

        $result = false;
        try {
            $result = $db->fetchCol($select);
        } catch (Zend_Db_Exception $e) {
            MyBlog_Log::getLogger()->err($e->getMessage());
            throw $e;
        }

        return $this->_fixPdoKeys($result);
    }
}
