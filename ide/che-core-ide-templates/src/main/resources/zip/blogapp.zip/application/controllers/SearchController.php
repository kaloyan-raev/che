<?php
require_once APPLICATION_PATH . '/models/Blogs.php';

class SearchController extends Zend_Controller_Action 
{
    public function indexAction() 
    {
        //Get the query from the form and search the index
        $query = $this->_getParam('title', null);

        $this->view->query = $query;
        
        if (!empty($query)) {
            $luceneResult = MyBlog_Search::search($query);
            $this->view->entries = $luceneResult;
        }
        
        //Get Recent entries from the database
        $modelBlogs    = new MyBlog_Model_Blogs();
        $this->view->recententries = $modelBlogs->getRecentEntries();
    }
}
