<?php

class Zend_View_Helper_LoginForm extends Zend_View_Helper_Abstract
{
    public function loginForm() 
    {
        $urlHome = $this->view->urlHome;
        if (!$loginForm = $this->view->form) {
            require_once APPLICATION_PATH . '/forms/Login.php';
            $loginForm = new MyBlog_Form_Login();
        }
        $loginForm->setMethod('post')
                  ->setAction("$urlHome/user/login")
                  ->setAttrib('style', 'margin: 1;');
        
        $loginFormHtml = <<<EOQ
<div id="login-form">
    
    <h3>Login to your Account</h3>
    $loginForm
</div>
EOQ;
        return $loginFormHtml;
    }
}
