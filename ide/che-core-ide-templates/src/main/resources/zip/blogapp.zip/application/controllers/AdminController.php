<?php
require_once APPLICATION_PATH . '/models/Blogs.php';
require_once APPLICATION_PATH . '/models/Comments.php';

class AdminController extends Zend_Controller_Action
{

    public function preDispatch()
    {
        $acl      = new MyBlog_Acl();
        $username = Zend_Auth::getInstance()->getIdentity()->username;
        if (!$acl->isAllowed($username, 'adminarea')) {
            $this->_redirect($this->view->urlHome . '/user');
        }
    }

    public function indexAction()
    {
    }

    public function newEntryAction()
    {
    }

    public function saveEntryAction()
    {
        $request = $this->getRequest();
        if (!$request->isPost()) {
            return $this->_helper->redirector('manage-entries');
        }

        require_once APPLICATION_PATH . '/forms/Entry.php';
        $form = new MyBlog_Form_Entry();

        if (!$form->isValid($request->getPost())) {
            $this->view->form      = $form;
            return $this->render('new-entry');
        }

        $entry      = $form->getValues();
        $modelBlogs = new MyBlog_Model_Blogs();
        $entryId    = $modelBlogs->createEntry($entry);

        if (!$entryId) {
            $this->view->message = 'Error saving entry to database; please try again later.';
            $this->view->form    = $form;
            return $this->render('new-entry');
        }

        $entry['entryId'] = $entryId;

        // add to Search index here
        MyBlog_Search::indexEntry($entry);

        $this->view->message = 'The blog entry was successfully added!';
        $this->_forward('manage-entries');
    }

    public function manageEntriesAction()
    {
        $modelBlogs = new MyBlog_Model_Blogs();

        // Default is list all entries
        $this->view->entries = $modelBlogs->getEntryTitles();
    }

    public function manageCommentsAction()
    {
        $modelComments        = new MyBlog_Model_Comments();
        $this->view->comments = $modelComments->getAllComments();
    }

    public function updateCommentAction()
    {
        $request       = $this->getRequest();
        $commentId     = $request->getParam('id', false);

        if (!$commentId) {
            return $this->_helper->redirector('manage-comments');
        }

        $modelComments        = new MyBlog_Model_Comments();
        switch (strtolower($request->getParam('display', ''))) {
            case 'hide':
                $modelComments->updateCommentStatus($commentId, MyBlog_Model_Comments::HIDE_COMMENT);
                break;
            case 'show':
                $modelComments->updateCommentStatus($commentId, MyBlog_Model_Comments::SHOW_COMMENT);
                break;
            default:
                break;
        }

        $this->_forward('manage-comments');
    }
}
