<?php
class ErrorController extends Zend_Controller_Action 
{
    public function errorAction()  
    {
        $errors    = $this->_getParam('error_handler');
        $exception = $errors->exception;
        
        MyBlog_Log::getLogger()->err($exception->getMessage() . "\n" .  $exception->getTraceAsString());

        switch ($errors->type) {
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:
            case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:
                // 404 error -- controller or action not found
                $this->getResponse()->setRawHeader('HTTP/1.1 404 Not Found');
                $content =<<<EOH
<h1>An Error Occured!</h1>
<p>The page you requested was not found.</p>
EOH;

                // ... get some output to display...
                break;
            default:
                // application error; display error page, but don't change
                // status code
                // Log the exception:
                $exception = $errors->exception;

                $content =<<<EOH
<h1>Error!</h1>
<p>An unexpected error occurred with your request. Please try again later.</p>
EOH;
                break;
        }

        $this->getResponse()->clearBody();
        $this->view->content = $content;
    }
}
