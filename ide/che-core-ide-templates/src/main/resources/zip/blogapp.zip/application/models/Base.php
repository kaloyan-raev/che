<?php
abstract class MyBlog_Model_Base
{
    protected function _fixPdoKeysRecursive(array $rowSet)
    {
        foreach ($rowSet as $key => $row) {
            $rowSet[$key] = $this->_fixPdoKeys($row);
        }
        return $rowSet;
    }

    protected function _fixPdoKeys($row)
    {
        $row = (array) $row;
        foreach ($row as $field => $value) {
            if (!preg_match('/^"[^"]+"\."([^"]+)"$/', $field, $matches)) {
                continue;
            }
            $newKey = $matches[1];
            unset($row[$field]);
            $row[$newKey] = $value;
        }
        return (object) $row;
    }
}
