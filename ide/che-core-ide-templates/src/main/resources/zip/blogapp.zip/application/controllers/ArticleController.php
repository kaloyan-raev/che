<?php
require_once APPLICATION_PATH . '/models/Blogs.php';
require_once APPLICATION_PATH . '/models/Comments.php';

class ArticleController extends Zend_Controller_Action
{
    public function viewAction()
    {
        $modelBlogs    = new MyBlog_Model_Blogs();
        $modelComments = new MyBlog_Model_Comments();

        $entryId = $this->_getParam('id', 0);
        $entry   = '';
        if ($entryId != 0) {
            $entry = $modelBlogs->getEntry($entryId);
            if ( 17 == $entryId )
                sleep(2); 
        }

        $this->view->entry         = $entry;
        $this->view->recententries = $modelBlogs->getRecentEntries();
        $this->view->comments      = $modelComments->getComments($entryId);
    }

    public function commentAction()
    {
        $request = $this->getRequest();

        if (!$id = $request->getParam('entry_id', false)) {
            $this->_redirect($this->view->urlHome);
        }

        if (!$request->isPost()) {
            return $this->_helper->redirector('view', null, null, array('id' => $id));
        }

        require_once APPLICATION_PATH . '/forms/Comment.php';
        $form = new MyBlog_Form_Comment();
        if (!$form->isValid($request->getPost())) {
            $this->view->form = $form;
            $this->view->message = 'There was one or more errors submitting your comment.';
            return $this->_forward('view', null, null, array('id' => $id));
        }

        $comment = $form->getValues();
        $comment['approvalStatus'] = 0;

        require_once APPLICATION_PATH . '/models/Comments.php';
        $model = new MyBlog_Model_Comments();
        if ($model->addComment($comment)) {
            $this->view->message = 'Your comment has been submitted.';
            MyBlog_Mail::mailNewComment($comment['title']);
        } else {
            $this->view->message = 'There was a problem adding your comment. Please try again!';
            $this->view->form    = $form;
        }
        $this->_forward('view', null, null, array('id' => $id));
    }
}
