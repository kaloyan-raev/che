<?php
require_once APPLICATION_PATH . '/models/Blogs.php';

class IndexController extends Zend_Controller_Action
{
    public function indexAction()
    {
        $this->view->pageTitle = "Main Page";

        $modelBlogs = new MyBlog_Model_Blogs();

        // Get all Entries
        $this->view->entries = $modelBlogs->getEntries();

        //Get Recent entries for the sidebar
        $this->view->recententries = $modelBlogs->getRecentEntries();

        // Getting the Yahoo weather feed on the sidebar.
        // Check if it is enabled in config

        if (Zend_registry::get('config')->yahoo->feed == 1) {
            $yWeatherUrl = 'https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22Chicago%22)&format=xml&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys';
            $yWeather    = MyBlog_Feeds::getYWeather($yWeatherUrl);

            // Initialize the channel data array
            $channel = array(
                'title'       => $yWeather->title(),
                'link'        => $yWeather->link(),
                'description' => $yWeather->description(),
                'items'       => array()
            );

            // Loop over each channel item and store relevant data
            foreach ($yWeather as $item) {
                $channel['items'][] = array(
                    'title'       => $item->title(),
                    'link'        => $item->link(),
                    'description' => $item->description()
                );
            }
            $this->view->channel = $channel;
        }
    }
}
