<?php
class FeedController extends Zend_Controller_Action
{
    public function init()
    {
        $this->_helper->viewRenderer->setNoRender(true);
    }

    public function getAction()
    {
        $request = $this->getRequest();
        $config  = Zend_Registry::get('config');

        $urlMyBlogRecentPosts = $config->url->myblog->recentposts;
        $urlMyBlogGetPost     = $config->url->myblog->getpost;

        //Get the method to be called, default = recentPosts
        $responseMethod = $request->getParam('do', 'recentposts');

        //Get an instance of the XML-RPC client
        $service = MyBlog_Service_Client::getInstance();
        $results = '';
        //Send request to the XML-RPC service
        switch ($responseMethod) {
            case 'recentposts':
                $results = $service->recentPosts();
                $title   = 'MyBlog Recent Entries';
                $link    = $urlMyBlogRecentPosts . '/feed/do/recentposts';
                break;
            case 'getpost':
                $entryId = $request->getParam('id');
                if ($entryId) {
                    $postDetails = $service->getPost($entryId);
                    if ($postDetails) {
                        $results[0]= $postDetails;
                    }
                }
                $title = 'Get Post';
                $link  = $urlMyBlogGetPost . '/feed/do/getpost/id/' . $entryId;
                break;
            default:
                $results = $service->recentPosts();
                $title   = 'MyBlog Recent Entries';
                $link    = $urlMyBlogRecentPosts . '/feed/do/recentposts';
                break;
        }

        if ($results) {
            //Get Syndication mode, Default is RSS
            $responseType = $request->getParam('type', 'rss');

            if ($responseType == 'json') {
                //Send JSON response to the browser
                echo Zend_Json::encode($results);
            } else {
                //Generate RSS feed

                //Generate a Zend_Feed compatible array to generate RSS feed
                $rssArray = MyBlog_Feeds::generateRssArray($responseMethod, $title, $link, $results);
                $rss      = '';
                if (is_array($rssArray) && !empty($rssArray)) {
                    //Returns a Zend_Feed_Rss object
                    $rss = Zend_Feed::importArray($rssArray, 'rss');
                }

                if (!$rss instanceof Zend_Feed_Rss) {
                    throw new MyBlog_Exception('Error generating RSS feed');
                }

                echo $rss->saveXML();
            }
        } else {
            echo "<h1>We're sorry! We did not find the feed you requested</h1>";
        }
    }
}
