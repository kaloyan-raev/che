<?php
class MyBlog_Form_Comment extends Zend_Form
{
    public function init()
    {
        $this->addElement('text', 'title', array(
            'label'     => 'Title for your comment',
            'size'      => 40,
            'maxlength' => 120,
            'required'  => true,
            'filters'   => array(
                'StringTrim',
            ),
            'validators' => array(
                array('StringLength', true, array(1, 120)),
            ),
        ));

        $this->addElement('text', 'email', array(
            'label'     => 'Your email address',
            'size'      => 40,
            'maxlength' => 120,
            'required'  => true,
            'filters'   => array(
                'StringTrim',
            ),
            'validators' => array(
                'EmailAddress',
            ),
        ));

        $this->addElement('textarea', 'comment', array(
            'label'     => 'Your comments',
            'required'  => true,
            'validators' => array(
                array('StringLength', true, array(1, 255)),
            ),
        ));

        $this->addElement('submit', 'add', array(
            'label'  => 'Add Comment',
            'size'   => 10,
            'ignore' => true,
        ));

        $this->addElement('hidden', 'entry_id', array(
            'required' => true,
        ));
    }
}
