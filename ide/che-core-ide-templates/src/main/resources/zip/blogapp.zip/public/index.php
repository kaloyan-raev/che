<?php
/**
 * Front controller 
 * 
 * @author Zend Technologies Inc.
 */

/**
 * Set the environment for this application (development, staging, qa, 
 * production, etc.); can be set in apache setenv directive. Makes it easy to 
 * switch between  development, staging and production environments.
 */
if (!$env = getenv('APPLICATION_ENV')) {
	$env = 'production'; // default
} 
defined('APPLICATION_ENV')
    || define('APPLICATION_ENV', $env);
defined('APPLICATION_PATH')
    || define('APPLICATION_PATH', realpath(dirname(__FILE__) . '/../application'));

/**
 * Set the application include_path to ensure that the application library is 
 * present. Once set, enable autoloading.
 */
set_include_path(
    realpath(APPLICATION_PATH . '/../library') 
    . PATH_SEPARATOR 
    . get_include_path()
);
require_once 'Zend/Loader/Autoloader.php';
$autoloader = Zend_Loader_Autoloader::getInstance();
$basicAutoloader = $autoloader->getDefaultAutoloader();
$autoloader->setDefaultAutoloader($basicAutoloader);
$autoloader->registerNamespace('MyBlog_');

// Execute the application bootstrap
require APPLICATION_PATH . '/bootstrap.php';

// Dispatch the front controller
Zend_Controller_Front::getInstance()->dispatch();
