/**
 * 
 */
$('document').ready(function() {
	$('a.lnk-view').on('click', function(event) {
		console.log('click ' + $(this).data('id'));
		
		event.defaultPrevented = true;
		return false;
	});
});