Zend Training Application
=======================

Extension of Zend Skeleton Application, showing ZF2 best practices.

Installation
---

Install composer dependencies:
```sh
	php composer.phar install
```

Either deploy the application on a Zend Server Instance or run the built-in server.

