<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Phonebook for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Phonebook\Form;

use Zend\InputFilter\InputFilterProviderInterface;
use Zend\Stdlib\Hydrator\ClassMethods as ClassMethodsHydrator;
use Zend\Form\Form;

/**
 * Contact form
 *
 * @package Phonebook
 * @subpackage Form
 * @version 1.0
 */
class Contact extends Form implements InputFilterProviderInterface
{
    /**
     * Constructor
     */
    public function __construct()
    {
        parent::__construct('person');
        $this->setHydrator(new ClassMethodsHydrator());
        $this->setAttribute('role', 'form');
        $this->setAttribute('novalidate', 'novalidate');
        $this->setObject(new \Phonebook\Entity\Contact());

        $this->add(array(
            'name' => 'id',
            'type' => 'hidden',
        ));

        $this->add(array(
            'name' => 'title',
            'type' => 'select',
            'options' => array(
                 'value_options' => array(
                    'Mr.' => 'Mr.',
                    'Mrs.' => 'Mrs.',
                    'Ms.' => 'Ms.',
                    'Dr.' => 'Dr.',
                ),
                'label' => 'Title:',
                'column-size' => 'sm-1',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'placeholder' => 'Contact title',
            ),
        ));

        $this->add(array(
            'name' => 'firstname',
            'type' => 'text',
            'options' => array(
                'label' => 'Firstname:',
                'column-size' => 'sm-10',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'placeholder' => 'Contact firstname',
            ),
        ));

        $this->add(array(
            'name' => 'lastname',
            'type' => 'text',
            'options' => array(
                'label' => 'Lastname:',
                'column-size' => 'sm-10',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'placeholder' => 'Contact lastname',
            ),
        ));

        $this->add(array(
            'name' => 'email',
            'type' => 'email',
            'options' => array(
                'label' => 'Email:',
                'column-size' => 'sm-10',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'placeholder' => 'Contact email',
            ),
        ));

        $this->add(array(
            'name' => 'address',
            'type' => 'text',
            'options' => array(
                'label' => 'Address:',
                'column-size' => 'sm-10',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'placeholder' => 'Contact address',
            ),
        ));

        $this->add(array(
            'name' => 'phone',
            'type' => 'text',
            'options' => array(
                'label' => 'Telphone:',
                'column-size' => 'sm-2',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'placeholder' => 'Contact phone',
            ),
        ));

        $this->add(array(
            'name' => 'notes',
            'type' => 'textarea',
            'options' => array(
                'label' => 'Notes:',
                'column-size' => 'sm-10',
                'label_attributes' => array('class' => 'col-sm-2'),
            ),
            'attributes' => array(
                'class' => 'form-control',
                'placeholder' => 'Contact notes',
            ),
        ));

        $this->add(array(
            'name' => 'csrf',
            'type' => 'csrf',
        ));

        $this->add(array(
            'name' => 'submit',
            'type' => 'submit',
            'options' => array(
                'label' => 'Save contact',
                'column-size' => 'sm-10 col-sm-offset-2',
            ),
            'attributes' => array(
                'class' => 'btn btn-success',
            )
        ));
    }

    /**
     * Should return an array specification compatible with
     * {@link Zend\InputFilter\Factory::createInputFilter()}.
     *
     * @return array
     */
    public function getInputFilterSpecification()
    {
        return array(
            'title' => array(
                'required' => true,
                'message' => 'Value must be either Mr.,Mrs., Ms., Dr.',
                'validators' => array(
                    array(
                        'name' => 'InArray',
                        'options' => array(
                            'haystack' => array('Mr.', 'Mrs.', 'Ms.', 'Dr.'),

                        ),
                    ),
                ),
            ),
            'firstname' => array(
                'required' => true,
                'filters' => array(
                    array(
                        'name' => 'StringTrim'
                    ),
                    array(
                        'name' => 'StripTags'
                    ),
                ),
                'validators' => array(
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'min' => 2,
                            'max' => 45,
                        ),
                    ),
                ),
            ),
            'lastname' => array(
                'required' => true,
                'filters' => array(
                    array(
                        'name' => 'StringTrim'
                    ),
                    array(
                        'name' => 'StripTags'
                    ),
                ),
                'validators' => array(
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'min' => 2,
                            'max' => 45,
                        ),
                    ),
                ),
            ),
            'email' => array(
                'required' => true,
                'filters' => array(
                    array(
                        'name' => 'StringTrim'
                    ),
                    array(
                        'name' => 'StripTags'
                    ),
                ),
                'validators' => array(
                    array(
                        'name' => 'EmailAddress',
                        'options' => array(
                            'message' => 'Email format invalid',
                        )
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'min' => 2,
                            'max' => 45,
                        ),
                    ),
                ),
            ),
            'address' => array(
                'required' => false,
                'filters' => array(
                    array(
                        'name' => 'StringTrim'
                    ),
                    array(
                        'name' => 'StripTags'
                    ),
                ),
                'validators' => array(
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'min' => 2,
                            'max' => 255,
                        ),
                    ),
                ),
            ),
            'phone' => array(
                'required' => false,
                'filters' => array(
                    array(
                        'name' => 'StringTrim'
                    ),
                    array(
                        'name' => 'StripTags'
                    ),
                ),
                'validators' => array(
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'min' => 2,
                            'max' => 20,
                        ),
                    ),
                ),
            ),
            'notes' => array(
                'required' => false,
                'filters' => array(
                    array(
                        'name' => 'StringTrim'
                    ),
                    array(
                        'name' => 'StripTags'
                    ),
                ),
            ),
        );
    }
}
