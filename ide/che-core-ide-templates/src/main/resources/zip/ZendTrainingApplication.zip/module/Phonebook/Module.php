<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Phonebook for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Phonebook;

use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\ModuleManager\Feature\ConfigProviderInterface;
use Zend\Mvc\MvcEvent;
use Zend\Console\Adapter\AdapterInterface as Console;

class Module implements AutoloaderProviderInterface, ConfigProviderInterface
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . str_replace('\\', '/' , __NAMESPACE__),
                ),
            ),
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    
    public function onBootstrap(MvcEvent $event) 
    {
        $locator = $event->getApplication()->getServiceManager();
        $contact = $locator->get('Phonebook\Service\Contact');
        
        $contact->getEventManager()->attach(\Phonebook\Service\Contact::EVENT_CONTACT_SAVE_ERROR, function ($event) use ($locator){
            $logger = $locator->get('Log\Phonebook');
            $logger->crit('Contact save error', $event->getParams());
        });
    }

    /**
     * Return the console usage for this module
     *
     * @param Console $console
     * @return array
     */
    public function getConsoleUsage(Console $console)
    {
        return array(
            'contact generate [<number>]'  => 'Generate <number> contacts in your DB (default 100)',
        );
    }
}
