<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Phonebook for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Phonebook\Controller;

use Zend\Mvc\Controller\AbstractActionController;

/**
 * Index Controller
 * 
 * @package Phonebook
 * @subpackage Controller
 * @version 1.0
 */
class IndexController extends AbstractActionController
{
    /**
     * Default action if none provided
     *
     * @return array
     */
    public function indexAction()
    {
        $this->redirect()->toRoute('phonebook/contact');
    }
}
